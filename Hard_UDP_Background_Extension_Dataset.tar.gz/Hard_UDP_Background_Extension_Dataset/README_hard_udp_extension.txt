Dataset name:
Hard UDP Background Extension Dataset

File:
hard_udp_background_extension_dataset.csv

Purpose:
This dataset was generated as an extension to test hard UDP-background scenarios where benign UDP traffic is high and low-rate UDP attack traffic is present.

Reason for extension:
The original dataset had only a small fixed amount of benign UDP background traffic. This extension adds higher benign UDP background traffic to strengthen protocol-bias analysis.

New parameter added:
n_udp_normal

Parameter values used:
n_udp_normal = 10, 30, 50
nTcp = 5, 20
n_attackers = 10, 30, 50
attack_rate = 500 Kbps
attack_type = constant, bursty, mixed
packet_size = 64, 512, 1024
attack_duration = short, long
seed = 1, 2

Total scenarios:
648

Dataset statistics:
Total records = 456,786
Normal records = 340,146
Attack records = 116,640

Protocol-label distribution:
TCP normal records = 165,186
UDP normal records = 174,960
UDP attack records = 116,640

Important note:
This extension dataset is kept separate from the original dataset. It has not been merged with the original dataset yet.
